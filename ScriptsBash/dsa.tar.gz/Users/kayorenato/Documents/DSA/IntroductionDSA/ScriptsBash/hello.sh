#!/bin/bash
Text="Hello World!"
echo $Text
