#!/bin/bash
# ==============================
# Script: backup.sh
# ==============================
tar -czf dsa.tar.gz ~/Documents/DSA

