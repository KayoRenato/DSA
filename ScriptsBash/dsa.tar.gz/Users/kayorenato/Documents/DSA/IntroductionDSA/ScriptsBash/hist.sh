#!/bin/bash
# ==============================
# Script: hist.sh
# ==============================
clear
echo "Informações do ambiente do usuário"
echo "================================================"
echo ""
echo "Olá: $USER"
echo ""
echo "Seu diretório home é: $HOME"
echo ""
echo "Seu cliente SSH é: $SSH_CLIENT"
echo ""
echo "Seu tipo de sessão terminal é: $TERM"
echo ""
